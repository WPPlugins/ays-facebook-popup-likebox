<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) )
	exit();

function ays_nk_delete_plugin() {
	delete_option("ays_nk_settings");
}

ays_nk_delete_plugin();
?>