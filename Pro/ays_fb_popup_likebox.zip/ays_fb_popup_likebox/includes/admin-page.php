<?php

/**********************************************************
*ADMIN PANEL
***********************************************************/
function ays_nk_options_page(){
    global $ays_nk_options;
    if(isset($ays_nk_options['ays_nk_article_type']))
      $except_arr = explode("@@", $ays_nk_options['ays_nk_article_type']);
    else
      $except_arr = array();
    ob_start();
    ?>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <div class="wrap">
	<form method="POST" action="options.php" id="#myForm">
        <h2 class="ays_nk_head">Facebook Page Smart Promoter</h2>
		<div class="tabs">
			<ul class="tab-liays_nks">
				<li class="active"><a href="#tab1">General</a></li>
				<li><a href="#tab2">Styles</a></li>
        <li><a href="#tab3">Assignments</a></li>
			</ul>

		<div class="tab-content">
			<div id="tab1" class="tab active">
				<p>General</p>


					<?php settings_fields('ays_nk_settings_group'); ?>

					<h4 class="ays_nk_inf">FB information</h4>
					<table align="center" cellpadding="20">
						<tr>
							<td class="ays_nk_table_cell">
								<label class="description" for="ays_nk_settings[fb_url]"><?php _e('Facebook page url','ays_nk_domain') ?><span class="desc"><b class="ays_top_arrow"></b>The URL of the facebook page for the likebox.</span></label>
							</td>
							<td>
								<input id="ays_nk_settings[fb_url]" class="ays_nk_res" name="ays_nk_settings[fb_url]" type="text" value="<?php echo $ays_nk_options['fb_url'];?>" />
							</td>
						</tr>
                        <tr>
                            <td>
                                <label class="description">Showing Effect<span class="desc"><b class="ays_top_arrow"></b>Effect for displaying likebox. If disabled likebox will appear with default style.</span></label>
                            </td>
                            <td>
                                <select name="ays_nk_settings[showEffect]" id="ays_nk_settings[showEffect]">
                                	<option value="" <?php if($ays_nk_options['showEffect'] == "") echo "selected"; ?> >Default</option>
									<optgroup label="Bouncing Entrances">
										<option value="bounceIn"  <?php if($ays_nk_options['showEffect'] == "bounceIn") echo "selected"; ?>>bounceIn</option>
										<option value="bounceInDown"  <?php if($ays_nk_options['showEffect'] == "bounceInDown") echo "selected"; ?>>bounceInDown</option>
										<option value="bounceInLeft"  <?php if($ays_nk_options['showEffect'] == "bounceInLeft") echo "selected"; ?>>bounceInLeft</option>
										<option value="bounceInRight"  <?php if($ays_nk_options['showEffect'] == "bounceInRight") echo "selected"; ?>>bounceInRight</option>
										<option value="bounceInUp"  <?php if($ays_nk_options['showEffect'] == "bounceInUp") echo "selected"; ?>>bounceInUp</option>
									</optgroup>
							
									<optgroup label="Fading Entrances">
										<option value="fadeIn"  <?php if($ays_nk_options['showEffect'] == "fadeIn") echo "selected"; ?>>fadeIn</option>
										<option value="fadeInDown"  <?php if($ays_nk_options['showEffect'] == "fadeInDown") echo "selected"; ?>>fadeInDown</option>
										<option value="fadeInDownBig"  <?php if($ays_nk_options['showEffect'] == "fadeInDownBig") echo "selected"; ?>>fadeInDownBig</option>
										<option value="fadeInLeft"  <?php if($ays_nk_options['showEffect'] == "fadeInLeft") echo "selected"; ?>>fadeInLeft</option>
										<option value="fadeInLeftBig"  <?php if($ays_nk_options['showEffect'] == "fadeInLeftBig") echo "selected"; ?>>fadeInLeftBig</option>
										<option value="fadeInRight"  <?php if($ays_nk_options['showEffect'] == "fadeInRight") echo "selected"; ?>>fadeInRight</option>
										<option value="fadeInRightBig"  <?php if($ays_nk_options['showEffect'] == "fadeInRightBig") echo "selected"; ?>>fadeInRightBig</option>
										<option value="fadeInUp"  <?php if($ays_nk_options['showEffect'] == "fadeInUp") echo "selected"; ?>>fadeInUp</option>
										<option value="fadeInUpBig"  <?php if($ays_nk_options['showEffect'] == "fadeInUpBig") echo "selected"; ?>>fadeInUpBig</option>
									</optgroup>
							
									<optgroup label="Flippers">
										<option value="flipInX"  <?php if($ays_nk_options['showEffect'] == "flipInX") echo "selected"; ?>>flipInX</option>
										<option value="flipInY"  <?php if($ays_nk_options['showEffect'] == "flipInY") echo "selected"; ?>>flipInY</option>
									</optgroup>
							
									<optgroup label="Lightspeed">
										<option value="lightSpeedIn"  <?php if($ays_nk_options['showEffect'] == "lightSpeedIn") echo "selected"; ?>>lightSpeedIn</option>
									</optgroup>
							
									<optgroup label="Rotating Entrances">
										<option value="rotateIn"  <?php if($ays_nk_options['showEffect'] == "rotateIn") echo "selected"; ?>>rotateIn</option>
										<option value="rotateInDownLeft"  <?php if($ays_nk_options['showEffect'] == "rotateInDownLeft") echo "selected"; ?>>rotateInDownLeft</option>
										<option value="rotateInDownRight"  <?php if($ays_nk_options['showEffect'] == "rotateInDownRight") echo "selected"; ?>>rotateInDownRight</option>
										<option value="rotateInUpLeft"  <?php if($ays_nk_options['showEffect'] == "rotateInUpLeft") echo "selected"; ?>>rotateInUpLeft</option>
										<option value="rotateInUpRight"  <?php if($ays_nk_options['showEffect'] == "rotateInUpRight") echo "selected"; ?>>rotateInUpRight</option>
									</optgroup>
							

							
									<optgroup label="Sliding Entrances">
										<option value="slideInUp"  <?php if($ays_nk_options['showEffect'] == "slideInUp") echo "selected"; ?>>slideInUp</option>
										<option value="slideInDown"  <?php if($ays_nk_options['showEffect'] == "slideInDown") echo "selected"; ?>>slideInDown</option>
										<option value="slideInLeft"  <?php if($ays_nk_options['showEffect'] == "slideInLeft") echo "selected"; ?>>slideInLeft</option>
										<option value="slideInRight"  <?php if($ays_nk_options['showEffect'] == "slideInRight") echo "selected"; ?>>slideInRight</option>
									</optgroup>

									
									<optgroup label="Zoom Entrances">
										<option value="zoomIn"  <?php if($ays_nk_options['showEffect'] == "zoomIn") echo "selected"; ?>>zoomIn</option>
										<option value="zoomInDown"  <?php if($ays_nk_options['showEffect'] == "zoomInDown") echo "selected"; ?>>zoomInDown</option>
										<option value="zoomInLeft"  <?php if($ays_nk_options['showEffect'] == "zoomInLeft") echo "selected"; ?>>zoomInLeft</option>
										<option value="zoomInRight"  <?php if($ays_nk_options['showEffect'] == "zoomInRight") echo "selected"; ?>>zoomInRight</option>
										<option value="zoomInUp"  <?php if($ays_nk_options['showEffect'] == "zoomInUp") echo "selected"; ?>>zoomInUp</option>
									</optgroup>
                                </select>
                            </td>
                        </tr>
						<tr>
                            <td>
                                <label class="description">Hiding Effect<span class="desc"><b class="ays_top_arrow"></b>Effect for displaying likebox. If disabled likebox will appear with default style.</span></label>
                            </td>
                            <td>
                                <select name="ays_nk_settings[hideEffect]" id="ays_nk_settings[hideEffect]">

									<option value="" <?php if($ays_nk_options['hideEffect'] == "") echo "selected"; ?> >Default</option>
									<optgroup label="Bouncing Exits">
										<option value="bounceOut"  <?php if($ays_nk_options['hideEffect'] == "bounceOut") echo "selected"; ?>>bounceOut</option>
										<option value="bounceOutDown"  <?php if($ays_nk_options['hideEffect'] == "bounceOutDown") echo "selected"; ?>>bounceOutDown</option>
										<option value="bounceOutLeft"   <?php if($ays_nk_options['hideEffect'] == "bounceOutLeft") echo "selected"; ?>>bounceOutLeft</option>
										<option value="bounceOutRight"  <?php if($ays_nk_options['hideEffect'] == "bounceOutRight") echo "selected"; ?>>bounceOutRight</option>
										<option value="bounceOutUp"  <?php if($ays_nk_options['hideEffect'] == "bounceOutUp") echo "selected"; ?>>bounceOutUp</option>
									</optgroup>
							
									<optgroup label="Fading Exits">
										<option value="fadeOut"  <?php if($ays_nk_options['hideEffect'] == "fadeOut") echo "selected"; ?>>fadeOut</option>
										<option value="fadeOutDown"  <?php if($ays_nk_options['hideEffect'] == "fadeOutDown") echo "selected"; ?>>fadeOutDown</option>
										<option value="fadeOutDownBig"  <?php if($ays_nk_options['hideEffect'] == "fadeOutDownBig") echo "selected"; ?>>fadeOutDownBig</option>
										<option value="fadeOutLeft"  <?php if($ays_nk_options['hideEffect'] == "fadeOutLeft") echo "selected"; ?>>fadeOutLeft</option>
										<option value="fadeOutLeftBig"  <?php if($ays_nk_options['hideEffect'] == "fadeOutLeftBig") echo "selected"; ?>>fadeOutLeftBig</option>
										<option value="fadeOutRight"  <?php if($ays_nk_options['hideEffect'] == "fadeOutRight") echo "selected"; ?>>fadeOutRight</option>
										<option value="fadeOutRightBig"  <?php if($ays_nk_options['hideEffect'] == "fadeOutRightBig") echo "selected"; ?>>fadeOutRightBig</option>
										<option value="fadeOutUp"  <?php if($ays_nk_options['hideEffect'] == "fadeOutUp") echo "selected"; ?>>fadeOutUp</option>
										<option value="fadeOutUpBig"  <?php if($ays_nk_options['hideEffect'] == "fadeOutUpBig") echo "selected"; ?>>fadeOutUpBig</option>
									</optgroup>
							
									<optgroup label="Flippers">
										<option value="flipOutX"  <?php if($ays_nk_options['hideEffect'] == "flipOutX") echo "selected"; ?>>flipOutX</option>
										<option value="flipOutY"  <?php if($ays_nk_options['hideEffect'] == "flipOutY") echo "selected"; ?>>flipOutY</option>
									</optgroup>
							
									<optgroup label="Lightspeed">
										<option value="lightSpeedOut"  <?php if($ays_nk_options['hideEffect'] == "lightSpeedOut") echo "selected"; ?>>lightSpeedOut</option>
									</optgroup>
							
									<optgroup label="Rotating Exits">
										<option value="rotateOut"  <?php if($ays_nk_options['hideEffect'] == "rotateOut") echo "selected"; ?>>rotateOut</option>
										<option value="rotateOutDownLeft"  <?php if($ays_nk_options['hideEffect'] == "rotateOutDownLeft") echo "selected"; ?>>rotateOutDownLeft</option>
										<option value="rotateOutDownRight"  <?php if($ays_nk_options['hideEffect'] == "rotateOutDownRight") echo "selected"; ?>>rotateOutDownRight</option>
										<option value="rotateOutUpLeft"  <?php if($ays_nk_options['hideEffect'] == "rotateOutUpLeft") echo "selected"; ?>>rotateOutUpLeft</option>
										<option value="rotateOutUpRight"  <?php if($ays_nk_options['hideEffect'] == "rotateOutUpRight") echo "selected"; ?>>rotateOutUpRight</option>
									</optgroup>
							
									<optgroup label="Sliding Exits">
										<option value="slideOutUp"  <?php if($ays_nk_options['hideEffect'] == "slideOutUp") echo "selected"; ?>>slideOutUp</option>
										<option value="slideOutDown"  <?php if($ays_nk_options['hideEffect'] == "slideOutDown") echo "selected"; ?>>slideOutDown</option>
										<option value="slideOutLeft"  <?php if($ays_nk_options['hideEffect'] == "slideOutLeft") echo "selected"; ?>>slideOutLeft</option>
										<option value="slideOutRight"  <?php if($ays_nk_options['hideEffect'] == "slideOutRight") echo "selected"; ?>>slideOutRight</option>
									</optgroup>
										
									<optgroup label="Zoom Exits">
										<option value="zoomOut"  <?php if($ays_nk_options['hideEffect'] == "zoomOut") echo "selected"; ?>>zoomOut</option>
										<option value="zoomOutDown"  <?php if($ays_nk_options['hideEffect'] == "zoomOutDown") echo "selected"; ?>>zoomOutDown</option>
										<option value="zoomOutLeft"  <?php if($ays_nk_options['hideEffect'] == "zoomOutLeft") echo "selected"; ?>>zoomOutLeft</option>
										<option value="zoomOutRight"  <?php if($ays_nk_options['hideEffect'] == "zoomOutRight") echo "selected"; ?>>zoomOutRight</option>
										<option value="zoomOutUp"  <?php if($ays_nk_options['hideEffect'] == "zoomOutUp") echo "selected"; ?>>zoomOutUp</option>
									</optgroup>
                                </select>
                            </td>
                        </tr>
						<tr>
							<td class="ays_nk_table_cell">
								<label class="description" for="ays_nk_settings[showOn]"><?php _e('Show on','ays_nk_domain') ?><span class="desc"><b class="ays_top_arrow"></b>Choose the amount of information from the promoted facebook page you want to be shown
                          on the likebox.
</span></label>
							</td>
							<td>
								<input id="ays_nk_settings[ays_nk_fb_timeL]" class="ays_nk_res" name="ays_nk_settings[ays_nk_fb_timeL]" type="checkbox" value="tl" <?php echo checked('tl', $ays_nk_options['ays_nk_settings[ays_nk_fb_timeL]']);?><?php if($ays_nk_options['ays_nk_fb_timeL'] == "tl") echo "checked"; ?>/>
								<label for="ays_nk_settings[ays_nk_fb_timeL]"> Timeline</label>

								<input id="ays_nk_settings[ays_nk_fb_evS]" class="ays_nk_res" name="ays_nk_settings[ays_nk_fb_evS]" type="checkbox" value="evS" <?php checked('evS', $ays_nk_options['ays_nk_settings[ays_nk_fb_evS]']);?> <?php if($ays_nk_options['ays_nk_fb_evS'] == "evS") echo "checked"?>  />
								<label for="ays_nk_settings[ays_nk_fb_evS]"> Events</label>

								<input id="ays_nk_settings[ays_nk_fb_mS]" class="ays_nk_res" name="ays_nk_settings[ays_nk_fb_mS]" type="checkbox" value="mS" <?php echo checked('mS', $ays_nk_options['ays_nk_settings[ays_nk_fb_mS]']);?><?php if($ays_nk_options['ays_nk_fb_mS'] == "mS") echo "checked"; ?>/>
								<label for="ays_nk_settings[ays_nk_fb_mS]"> Messages</label>
							</td>
						</tr>
						<tr>
							<td class="ays_nk_table_cell">
								<label class="description" for="ays_nk_settings[ays_nk_fb_chgs]"><?php _e('Use in FB plugin','ays_nk_domain') ?><span class="desc"><b class="ays_top_arrow"></b>Customize the Facebook Likebox's appearance. If you choose “small header”, then it will display the small facebook header at the top of the likebox. If you choose “hide cover photos”, then it will not display the cover photos from the page’s wall. And if you choose the third variant, i.e. “show friends’ faces”, then it will display profile photos in the Likebox.</span></label>
							</td>
							<td>
								<input id="ays_nk_settings[ays_nk_fb_chgs1]" class="ays_nk_res" name="ays_nk_settings[ays_nk_fb_chgs1]" type="checkbox" value="sm" <?php echo checked('sm', $ays_nk_options['ays_nk_settings[ays_nk_fb_chgs1]']);?><?php if($ays_nk_options['ays_nk_fb_chgs1'] == "sm") echo "checked"; ?>/>
								<label for="ays_nk_settings[ays_nk_fb_chgs1]">Small header</label>

								<input id="ays_nk_settings[ays_nk_fb_chgs2]" class="ays_nk_res" name="ays_nk_settings[ays_nk_fb_chgs2]" type="checkbox" value="hcf" <?php checked('hcf', $ays_nk_options['ays_nk_settings[ays_nk_fb_chgs2]']);?> <?php if($ays_nk_options['ays_nk_fb_chgs2'] == "hcf") echo "checked"?>  />
								<label for="ays_nk_settings[ays_nk_fb_chgs2]">Hide Cover Photoes</label>

								<input id="ays_nk_settings[ays_nk_fb_chgs3]" class="ays_nk_res" name="ays_nk_settings[ays_nk_fb_chgs3]" type="checkbox" value="sff" <?php echo checked('sff', $ays_nk_options['ays_nk_settings[ays_nk_fb_chgs3]']);?><?php if($ays_nk_options['ays_nk_fb_chgs3'] == "sff") echo "checked"; ?>/>
								<label for="ays_nk_settings[ays_nk_fb_chgs3]">Show Friend Faces</label>

							</td>
						</tr>
                        <tr>
							<td class="ays_nk_table_cell">
								<label class="description" for="ays_nk_settings[ays_nk_fb_bounce]"><?php _e('Enable amazing effect','ays_nk_domain') ?><span class="desc"><b class="ays_top_arrow"></b>When likebox fully appeared, modal window will be animated.</span></label>
							</td>
							<td>
								<select id="ays_nk_settings[ays_nk_fb_animate]"  name="ays_nk_settings[ays_nk_fb_animate]">
										<option value="" <?php if($ays_nk_options['ays_nk_fb_animate'] == "") echo "selected"; ?>>Default </option>
									<optgroup label="Attention Seekers">
										<option value="bounce" <?php if($ays_nk_options['ays_nk_fb_animate'] == "bounce") echo "selected"; ?>>bounce</option>
										<option value="flash"  <?php if($ays_nk_options['ays_nk_fb_animate'] == "flash") echo "selected"; ?>>flash</option>
										<option value="pulse"  <?php if($ays_nk_options['ays_nk_fb_animate'] == "pulse") echo "selected"; ?>>pulse</option>
										<option value="rubberBand"  <?php if($ays_nk_options['ays_nk_fb_animate'] == "rubberBand") echo "selected"; ?>>rubberBand</option>
										<option value="shake"  <?php if($ays_nk_options['ays_nk_fb_animate'] == "shake") echo "selected"; ?>>shake</option>
										<option value="swing"   <?php if($ays_nk_options['ays_nk_fb_animate'] == "swing") echo "selected"; ?>>swing</option>
										<option value="tada"  <?php if($ays_nk_options['ays_nk_fb_animate'] == "tada") echo "selected"; ?>>tada</option>
										<option value="wobble"  <?php if($ays_nk_options['ays_nk_fb_animate'] == "wobble") echo "selected"; ?>>wobble</option>
										<option value="jello"  <?php if($ays_nk_options['ays_nk_fb_animate'] == "jello") echo "selected"; ?>>jello</option>
									</optgroup>
								</select>
							</td>
						</tr>
						<tr>
							<td>
								<label class="description" for="ays_nk_settings[wlogged]"><?php _e('Show only to WP logged in users','ays_nk_domain') ?><span class="desc"><b class="ays_top_arrow"></b>If your user logged in your website it will show only for him,else likebox wouldn't appear.</span></label>						
							</td>
							<td>
								<input type="radio" name="ays_nk_settings[wlogged]" id="ays_nk_settings[wlogged_enable]" class="ays_nk_res" value="true" <?php checked('true', $ays_nk_options['wlogged']); ?>>
								<label for="ays_nk_settings[wlogged_enable]">Enable</label>
								<input type="radio" name="ays_nk_settings[wlogged]" id="ays_nk_settings[wlogged_disable]" class="ays_nk_res" value="false" <?php checked('false', $ays_nk_options['wlogged']); ?>>
								<label for="ays_nk_settings[wlogged_disable]">Disable</label>
							</td>
						</tr>						
						<tr>
							<td class="ays_nk_table_cell">
								<label class="description" for="ays_nk_settings[lang]"><?php _e('Language','ays_nk_domain') ?><span class="desc"><b class="ays_top_arrow"></b>Choose the language that the likebox appears in.</span></label>
							</td>
							<td>
                                <?php
                         $ays_lang_arr=array("Afrikaans","Arabic","Azerbaijani","Belarusian","Bulgarian","Bengali","Bosnian","Catalan","Czech","Cebuano","Welsh","Danish","German","Greek","English (UK)","English (Pirate)","English (Upside Down)","English (US)","Esperanto","Spanish","Spanish","Estonian","Basque","Persian","Leet Speak","Finnish","Faroese","French(Canada)","French(France)","Frisian","Irish","Galician","Guarani","Hebrew","Hindi","Croatian","Hungarian","Armenian","Indonesian","Icelandic","Italian","Japanese","Javanese","Georgian","Khmer","Kannada","Korean","Kurdish","Latin","Lithuanian","Latvian","Macedonian","Malayalam","Malay","Norwegian(bokmal)","Nepali","Dutch","Norwegian(nynorsk)","Punjabi","Polish","Pashto","Portuguese(Brazil)","Portuguese(Portugal)","Romanian","Russian","Sinhala","Slovak","Slovenian","Albanian","Serbian","Swedish","Swahili","Tamil","Telugu","Thai","Filipino","Turkish","Ukrainian","Urdu","Vietnamese","Simplified Chinese (China)","Traditional Chinese (Hong Kong)","Traditional Chinese (Taiwan)");
                         $ays_lang_short_arr=array("af_ZA","ar_AR","az_AZ","be_BY","bg_BG","bn_IN","bs_BA","ca_ES","cs_CZ","cx_PH","cy_GB","da_DK","de_DE","el_GR","en_GB","en_PI","en_UD","en_US","eo_EO","es_ES","es_LA","et_EE","eu_ES","fa_IR","fb_LT","fi_FI","fo_FO","fr_CA","fr_FR","fy_NL","ga_IE","gl_ES","gn_PY","he_IL","hi_IN","hr_HR","hu_HU","hy_AM","id_ID","is_IS","it_IT","ja_JP","jv_ID","ka_GE","km_KH","kn_IN","ko_KR","ku_TR","la_VA","lt_LT","lv_LV","mk_MK","ml_IN","ms_MY","nb_NO","ne_NP","nl_NL","nn_NO","pa_IN","pl_PL","ps_AF","pt_BR","pt_PT","ro_RO","ru_RU","si_LK","sk_SK","sl_SI","sq_AL","sr_RS","sv_SE","sw_KE","ta_IN","te_IN","th_TH","tl_PH","tr_TR","uk_UA","ur_PK","vi_VN","zh_CN","zh_HK","zh_TW" );
                                ?>
                                <select id="ays_nk_settings[lang]" class="ays_nk_res" name="ays_nk_settings[lang]">
                                    <option>Select Language</option>
                                    <?php
                                        for($ost = 0; $ost<count($ays_lang_arr); $ost++){
                                            if($ays_nk_options['lang'] == $ays_lang_short_arr[$ost]){
                                                echo '<option value="'.$ays_lang_short_arr[$ost].'" selected>'.$ays_lang_arr[$ost].'</option>';
                                            }
                                            else{
                                                echo '<option value="'.$ays_lang_short_arr[$ost].'">'.$ays_lang_arr[$ost].'</option>';
                                            }
                                        }
                                    ?>
                                </select>
							</td>
						</tr>
						<tr>
							<td class="ays_nk_table_cell">
								<label class="description" for="ays_nk_settings[width]"><?php _e('Width','ays_nk_domain') ?><span class="desc"><b class="ays_top_arrow"></b>The width of the likebox in pixels.</span></label>
							</td>
							<td>
								<input id="ays_nk_settings[width]" class="ays_nk_res" name="ays_nk_settings[width]" type="text" value="<?php echo $ays_nk_options['width']; ?>" />
							</td>
						</tr>
						<tr>
							<td class="ays_nk_table_cell">
								<label class="description" for="ays_nk_settings[height]"><?php _e('Height','ays_nk_domain') ?><span class="desc"><b class="ays_top_arrow"></b>The height of the likebox in pixels.</span></label>
							</td>
							<td>
								<input id="ays_nk_settings[height]" class="ays_nk_res" name="ays_nk_settings[height]" type="text" value="<?php echo $ays_nk_options['height'];?>" />
							</td>
						</tr>
						<tr>
							<td class="ays_nk_table_cell">
								<label class="description" for="ays_nk_settings[delay]"><?php _e('Delay (e.g>1000ms)','ays_nk_domain') ?><span class="desc"><b class="ays_top_arrow"></b>Specify a delay for the likebox to appear (recommended > 1000)/ or  The best time
                                           to display the likebox to a visitor automatically.
</span></label>
							</td>
							<td>
								<input id="ays_nk_settings[delay]" class="ays_nk_res" name="ays_nk_settings[delay]" type="text" value="<?php echo $ays_nk_options['delay']; ?>" />
							</td>
						</tr>
						<tr>
							<td class="ays_nk_table_cell">
								<label class="description"><?php _e('Disable close button','ays_nk_domain') ?><span class="desc"><b class="ays_top_arrow"></b>This option disables the visitor to close the likebox until the visitor likes the
                                            promoted page or until the likebox is auto closed.
</span></label>
							</td>
							<td>
								<input id="ays_nk_settings[soe]" class="ays_nk_res" name="ays_nk_settings[ecb]" type="checkbox" <?php if(!empty($ays_nk_options['ecb'])) echo "checked"; ?> /><label for="ays_nk_settings[soe]">Disable</label>
							</td>
						</tr>
						<tr>
							<td>
								<label class="description" for="ays_nk_settings[coo]"><?php _e('Close on overlay click','ays_nk_domain') ?><span class="desc"><b class="ays_top_arrow"></b>Enable or disable overlay click.</span></label>						
							</td>
							<td>
								<input type="radio" name="ays_nk_settings[coo]" id="ays_nk_settings[coo_enable]" class="ays_nk_res" value="true" <?php checked('true', $ays_nk_options['coo']); ?>>
								<label for="ays_nk_settings[coo_enable]">Enable</label>
								<input type="radio" name="ays_nk_settings[coo]" id="ays_nk_settings[coo_disable]" class="ays_nk_res" value="false" <?php checked('false', $ays_nk_options['coo']); ?>>
								<label for="ays_nk_settings[coo_disable]">Disable</label>
							</td>
						</tr>						
						<tr>
							<td class="ays_nk_table_cell">
								<label class="description"><?php _e('Disable auto close','ays_nk_domain') ?><span class="desc"><b class="ays_top_arrow"></b>By this option the likebox will be closed as soon as the visitor likes the promoted page
                                        or closes the likebox with the close button.
</span></label>
							</td>
							<td>
								<input id="ays_nk_settings[dac]" onchange="ays_nk_func()" class="ays_nk_res" name="ays_nk_settings[dac]" type="checkbox" <?php if(!empty($ays_nk_options['dac'])) echo "checked"; ?> /><label for="ays_nk_settings[dac]">Disable</label>
							</td>
						</tr>
						<tr>
							<td class="ays_nk_table_cell">
								<label class="description" id="a_u_c_l" for="ays_nk_settings[aucl]"><?php _e('Auto close per seconds','ays_nk_domain') ?><span class="desc"><b class="ays_top_arrow"></b>Specify the amount of time for the likebox to auto close.</span></label>
							</td>

							<td>
                                                            <table>
                                                                <tr>
                                                                    <td>
                                                                        <input type="text" id="ays_nk_settings[tfaucl1]" class="ays_nk_res" name="ays_nk_settings[tfaucl1]"  value="<?php echo $ays_nk_options['tfaucl1'];?>" />
                                                                    </td>
                                                                    <td>
                                                                        <input id="ays_nk_settings[aucl]" style="width:100%" class="ays_nk_res" name="ays_nk_settings[aucl]" type="number" value="<?php echo $ays_nk_options['aucl'];?>"/>
                                                                    </td>
                                                                    <td>
                                                                        <input type="text" id="ays_nk_settings[tfaucl2]" class="ays_nk_res" name="ays_nk_settings[tfaucl2]"  value="<?php echo $ays_nk_options['tfaucl2'];?>" >
                                                                    </td>
                                                                </tr>
                                                            </table>
							</td>
						</tr>
						<tr>
							<td class="ays_nk_table_cell">
								<label class="description" for="ays_nk_settings[siev]"><?php _e('Show once every (days,hours,minutes)','ays_nk_domain') ?><span class="desc"><b class="ays_top_arrow"></b>Show the likebox once in the defined
                                                                                                                        amount of time per individual visitor.
</span></label>
							</td>
							<td>
								<input class="ays_nk_res" id="ays_nk_settings[siev]" name="ays_nk_settings[siev]" type="number" value="<?php echo $ays_nk_options['siev']; ?>" />
								<?php
									$ays_cook_arr=array("Days","Hours","Minutes");
									$ays_cook_short_arr=array("day","hour","minute");
								?>
								<select id="ays_nk_settings[cook]" class="ays_nk_res" name="ays_nk_settings[cook]">
									<option>Select Format</option>
									<?php
										for($nk_ost = 0; $nk_ost<count($ays_cook_arr); $nk_ost++){
											if($ays_nk_options['cook'] == $ays_cook_short_arr[$nk_ost]){
												echo '<option value="'.$ays_cook_short_arr[$nk_ost].'" selected>'.$ays_cook_arr[$nk_ost].'</option>';
											}
											else{
												echo '<option value="'.$ays_cook_short_arr[$nk_ost].'">'.$ays_cook_arr[$nk_ost].'</option>';
											}
										}
									?>
								</select>
							</td>
						</tr>
						<tr>
							<td class="ays_nk_table_cell">
								<label class="description" for="ays_nk_settings[tbl]"><?php _e('Likebox title','ays_nk_domain') ?><span class="desc"><b class="ays_top_arrow"></b>Choose the title of the likebox, which will be shown at the top of the
                                                              box.
</span></label>
							</td>
							<td>
								<input id="ays_nk_settings[tbl]" class="ays_nk_res" name="ays_nk_settings[tbl]" type="text" value="<?php echo $ays_nk_options['tbl'];?>" />
							</td>
						</tr>
						<tr>
							<td colspan="2" align="center">
								<input type="submit" class="button-primary" value="<?php _e('Save Options','ays_nk_domain');?>" />
								<input type="button"  id="ays_nk_bttn"  value="<?php _e('Reset Options','ays_nk_domain');?>" class="my_butt"/>
							</td>
						</tr>
					</table>

			</div>

			<div id="tab2" class="tab">
				<p>Styles</p>


					<h4 class="ays_nk_inf">Page Promoter Styles</h4>
					<table align="center" cellpadding="20">
						<tr>
							<td class="ays_nk_table_cell">
								<label class="description"><?php _e('Modal Border Color:','ays_nk_domain') ?><span class="desc"><b class="ays_top_arrow"></b>Set the color of the border around the likebox.</span></label>
							</td>
							<td>
							<div class="ays_nk_new_div">
								<div class="ays_nk_new_div1">
									<input type="text" name="ays_nk_settings[ays_nk_bor_col]" value="<?php echo $ays_nk_options['ays_nk_bor_col'] ?>" class="my-color-field" data-default-color="#effeff" />
								</div>
							</div>
							</td>
						</tr>						
						<tr>
							<td>
								<label class="description"><?php _e('Transparent background','ays_nk_domain') ?><span class="desc"><b class="ays_top_arrow"></b>Set the transparent background for likebox.</span></label>
							</td>
							<td>
								<input type="radio" name="ays_nk_settings[tbg]" id="ays_nk_settings[tbg_enable]" class="ays_nk_res" value="true" <?php checked('true', $ays_nk_options['tbg']); ?>>
								<label for="ays_nk_settings[tbg_enable]">Enable</label>
								<input type="radio" name="ays_nk_settings[tbg]" id="ays_nk_settings[tbg_disable]" class="ays_nk_res" value="false" <?php checked('false', $ays_nk_options['tbg']); ?>>
								<label for="ays_nk_settings[tbg_disable]">Disable</label>							
							</td>
						</tr>
						<tr>
							<td class="ays_nk_table_cell">
								<label class="description"><?php _e('Modal Background Color:','ays_nk_domain') ?><span class="desc"><b class="ays_top_arrow"></b>Choose the background color of the likebox.</span></label>
							</td>
							<td>
								<div class="ays_nk_new_div">
									<div class="ays_nk_new_div2">
									<input type="text" name="ays_nk_settings[ays_nk_mod_col]" value="<?php echo $ays_nk_options['ays_nk_mod_col'] ?>" class="my-color-field" data-default-color="#effeff" />
									</div>
								</div>
							</td>
						</tr>
						<tr>
							<td class="ays_nk_table_cell">
								<label class="description"><?php _e('Modal Border Radius:','ays_nk_domain') ?><span class="desc"><b class="ays_top_arrow"></b>Choose the level of the rounded corners of the likebox.
</span></label>
							</td>
							<td>
								<input type="number" name="ays_nk_settings[ays_nk_bor_rad]" id="ays_nk_settings[ays_nk_bor_rad]" value="<?php echo $ays_nk_options['ays_nk_bor_rad'] ?>" min="0" max="100" step="1"/>
							</td>
						</tr>
						<tr>
							<td class="ays_nk_table_cell">
								<label class="description"><?php _e('Modal Border Thickness:','ays_nk_domain') ?><span class="desc"><b class="ays_top_arrow"></b>Set the thickness of the border around the likebox.</span></label>
							</td>
							<td>
								<input type="number" name="ays_nk_settings[ays_nk_bor_th]" id="ays_nk_settings[ays_nk_bor_th]" value="<?php if($ays_nk_options['ays_nk_bor_th']!="")echo $ays_nk_options['ays_nk_bor_th'];else echo 1; ?>" min="0" max="100" step="1"/>
							</td>
						</tr>
						<tr>
							<td class="ays_nk_table_cell">
								<label class="description"><?php _e('Opacity Background Color:','ays_nk_domain') ?><span class="desc"><b class="ays_top_arrow"></b>Change the background color. You can change it any color you
                                                      like.
</span></label>
							</td>
							<td>
							<div class="ays_nk_new_div">
								<div class="ays_nk_new_div3">
								<input type="text" name="ays_nk_settings[ays_nk_opac_col]" value="<?php echo $ays_nk_options['ays_nk_opac_col'] ?>" class="my-color-field" data-default-color="#effeff" />
								</div>
							</div>
							</td>
						</tr>
						<tr>
							<td class="ays_nk_table_cell">
								<label class="description"><?php _e('Opacity Level 0-1:','ays_nk_domain') ?><span class="desc"><b class="ays_top_arrow"></b>Set the transparency level of the background. It is a scale of 0-1. If you want it entirely opaque, you just put a 1 in there. But if you want it to be very see through, then you put 0.1.</span></label>
							</td>
							<td>
								<input type="number" name="ays_nk_settings[ays_nk_opac_lev]" id="ays_nk_settings[ays_nk_opac_lev]" value="<?php echo $ays_nk_options['ays_nk_opac_lev'] ?>" min="0" max="1" step="0.1"/>
							</td>
						</tr>
            <tr>
							<td class="ays_nk_table_cell">
								<label class="description"><?php _e('Close Button Color:','ays_nk_domain') ?><span class="desc"><b class="ays_top_arrow"></b>Set the color of the close button.</span></label>
							</td>
							<td>
							<div class="ays_nk_new_div">
								<div class="ays_nk_new_div4">
									<input type="text" name="ays_nk_settings[ays_nk_close_col]" value="<?php echo $ays_nk_options['ays_nk_close_col'] ?>" class="my-color-field" data-default-color="#effeff" />
								</div>
							</div>
							</td>
						</tr>
						<tr>
							<td class="ays_nk_table_cell">
								<label class="description" for="ays_nk_settings[ays_nk_ccss]"><?php _e('Custom Css:','ays_nk_domain') ?><span class="desc"><b class="ays_top_arrow"></b>If you need to configure the CSS style of Facebook Popup Likebox on your own, then you can just add any style you wish to Custom Css field and make your modifications there. </span></label>
							</td>
							<td>
								<textarea class="ays_nk_res" id="ays_nk_settings[ays_nk_ccss]" name="ays_nk_settings[ays_nk_ccss]" type="text"><?php echo $ays_nk_options['ays_nk_ccss']; ?></textarea>
							</td>
						</tr>
						<tr>
							<td colspan="2" align="center">
								<input type="submit" class="button-primary" value="<?php _e('Save Options','ays_nk_domain');?>" />
								<input type="button"  id="ays_nk_bttn1"  value="<?php _e('Reset Options','ays_nk_domain');?>"  class="my_butt"/>
							</td>
						</tr>
					</table>

			</div>
      <div id="tab3" class="tab" style="min-height:500px">
        <style>
          .ays_post_page{display: none;}
        </style>
        <table>
            <tr>
                <td>
                    <label class="description" for="ays_nk_settings[ays_nk_article_place]"><?php _e('Choose post/page:','ays_nk_domain') ?><span class="desc"><b class="ays_top_arrow"></b>Choose the post or page (in WordPress default Homepage is all the same with Hello World post page), where you want the likebox to be shown on.</span></label>
                </td>
                <td>
                    <?php
                      $ays_article_place_name = array("No posts/pages","On all posts/pages","On all posts/pages except those selected");
                      $ays_article_place_val = array("none","all","except");
                    ?>
                    <select id="ays_nk_settings[ays_nk_article_place]" name="ays_nk_settings[ays_nk_article_place]" class="ays_publishing_art">
                        <option>Select post/page</option>
                        <?php
                          foreach ($ays_article_place_name as $index=>$ays_name_value) {
                            if($ays_article_place_val[$index] == $ays_nk_options['ays_nk_article_place']){
                              echo "<option value='".$ays_article_place_val[$index]."' selected>".$ays_name_value."</option>";
                            }
                            else{
                              echo "<option value='".$ays_article_place_val[$index]."'>".$ays_name_value."</option>";
                            }
                          }
                        ?>
                    </select>
                </td>
            </tr>
            <tr class="ays_post_page">
                <td>
                  <p>Select post or pages</p>
                </td>
                <td>
                  <ul name="page-dropdown">
                     <?php
                      $pages = get_pages();
                      foreach ( $pages as $page ) {
                          $checked=((in_array($page->ID,$except_arr)) || empty($except_arr)) ? "checked='checked'" : "";
                          echo "<li><label for='select_page_".$page->ID."'><input type='checkbox' class='select_page' ".$checked." value='".$page->ID."' id='select_page_".$page->ID."'>".$page->post_title."</label></li>";
                      }
                      $posts = get_posts();
                      foreach ( $posts as $post ) {
                          $checked=((in_array($post->ID,$except_arr)) || empty($except_arr)) ? "checked='checked'" : "";
                          echo "<li><label for='select_page_".$post->ID."'><input type='checkbox' class='select_page' ".$checked." value='".$post->ID."' id='select_page_".$post->ID."'>".$post->post_title."</label></li>";
                      }
                     ?>
                  </ul>
                </td>
            </tr>
            <tr>
							<td colspan="2" align="center">
								<input type="submit" class="button-primary" value="<?php _e('Save Options','ays_nk_domain');?>" />
								<input type="button"  id="ays_nk_bttn1"  value="<?php _e('Reset Options','ays_nk_domain');?>"  class="my_butt"/>
							</td>
						</tr>
        </table>
        <script>
                jQuery(document).ready(function(){
                  var ays_selected_pages = new Array();
                  var ays_all_pages = new Array();
                  jQuery(".select_page").each(function(){
                    if(jQuery(this).prop("checked") == true){
                      ays_selected_pages.push(jQuery(this).val());
                    }
                  });
                  if(jQuery(".ays_publishing_art option:selected").val() == "except"){
                    jQuery(".ays_post_page").css("display","table-row");
                    jQuery(".select_page").change(function(){
                      if(jQuery(this).prop("checked") == true){
                        ays_selected_pages.push(jQuery(this).val());
                        jQuery(".ays_article_type_inp").val(ays_selected_pages.join("@@"));
                      }
                      else{
                        ays_selected_pages.splice( jQuery.inArray(jQuery(this).val(), ays_selected_pages), 1 );
                        jQuery(".ays_article_type_inp").val(ays_selected_pages.join("@@"));
                      }
                    });
                  }
                  jQuery(".ays_publishing_art").change(function(){
                    if(jQuery(".ays_publishing_art option:selected").val() == "except"){
                      jQuery(".ays_post_page").css("display","table-row");
                      jQuery(".select_page").change(function(){
                        if(jQuery(this).prop("checked") == true){
                          ays_selected_pages.push(jQuery(this).val());
                          jQuery(".ays_article_type_inp").val(ays_selected_pages.join("@@"));
                        }
                        else{
                          ays_selected_pages.splice( jQuery.inArray(jQuery(this).val(), ays_selected_pages), 1 );
                          jQuery(".ays_article_type_inp").val(ays_selected_pages.join("@@"));
                        }
                      });
                    }
                    else{
                      if(jQuery(".ays_publishing_art option:selected").val() == "all"){
                        jQuery(".select_page").each(function(){
                          ays_all_pages.push(jQuery(this).val());
                        });
                        jQuery(".ays_article_type_inp").val(ays_all_pages.join("@@"));
                      }
                      if(jQuery(".ays_publishing_art option:selected").val() == "none"){
                        jQuery(".ays_article_type_inp").removeAttr("value");
                      }
                      jQuery(".ays_post_page").css("display","none");
                    }
                  });
                });
        </script>

        <input type="hidden" id="ays_nk_settings[ays_nk_article_type]" class="ays_article_type_inp" name="ays_nk_settings[ays_nk_article_type]" value="<?php echo  $ays_nk_options['ays_nk_article_type']; ?>">
      </div>
		</div>
	</div>
    </form>
    </div>
    <?php
    echo ob_get_clean();
}
function ays_nk_add_options_liays_nk(){
    add_options_page('AYS Facebook Popoup Likebox Options','FPSPopoup','manage_options','ays_nk-options','ays_nk_options_page');
    add_menu_page('FPSPopoup', 'AYS Facebook Popoup Likebox', 'manage_options', 'ays_nk-options', 'ays_nk_options_page');
}
add_action('admin_menu','ays_nk_add_options_liays_nk');

function ays_nk_register_settings(){
    register_setting('ays_nk_settings_group','ays_nk_settings');
}
add_action('admin_init','ays_nk_register_settings');
?>
